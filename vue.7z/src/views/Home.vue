<template>
  <div class="home">
    <h1>记账管理系统</h1>
  </div>
</template>

<script setup>
</script>

<style scoped>
.home {
  padding: 20px;
}
</style> 