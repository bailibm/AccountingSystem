<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { userApi } from '../../api/user'  // 修改导入路径
import { ElMessage, ElMessageBox } from 'element-plus'
// ... 其余代码保持不变
</script> 