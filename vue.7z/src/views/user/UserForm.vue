<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { userApi } from '../../api/user'  // 修改导入路径
import { ElMessage } from 'element-plus'
// ... 其余代码保持不变
</script> 