package com.example.jizhang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiZhangApplicationTests {

    @Test
    void contextLoads() {
    }

}
